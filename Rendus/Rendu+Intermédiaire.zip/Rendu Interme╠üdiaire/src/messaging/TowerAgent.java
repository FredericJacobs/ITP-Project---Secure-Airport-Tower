package messaging;

public class TowerAgent {

	public double getPosX() {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean hasCrashed() {
		// TODO Auto-generated method stub
		return false;
	}

	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}


}
